#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <omp.h>

#define STUDENT_ID 230103082ULL
#define N (10000000ULL + (STUDENT_ID % 10000ULL) * 1000ULL)
#define MOD 1000000007ULL
#define MAX_THREADS 64

static inline uint32_t collatz_steps(uint64_t n) {
    uint32_t steps = 0;
    while (n > 1) {
        if ((n & 1) == 0) n >>= 1;
        else n = 3 * n + 1;
        steps++;
    }
    return steps;
}

struct PaddedCounter {
    int count;
    char pad[60]; // Дополнение до 64 байт (размер L1/L2 кэш-линии)
};

int main() {
    printf("==================================================\n");
    printf("  AMDAHL REALITY GAP BENCHMARK (ID: %llu)\n", STUDENT_ID);
    printf("  Target Workload N: %llu\n", N);
    printf("  Max Logical Threads: %d\n", omp_get_max_threads());
    printf("==================================================\n\n");

    // ----------------------------------------------------
    // PHASE 2: Sequential Baseline & Precision Timing
    // ----------------------------------------------------
    printf("--- Phase 2: Sequential Baseline ---\n");
    double seq_times[3];
    uint64_t checksum = 0;
    uint32_t max_steps_seq = 0;

    for (int run = 0; run < 3; run++) {
        double start = omp_get_wtime();
        uint64_t sum = 0;
        uint32_t max_s = 0;

        for (uint64_t i = 1; i <= N; i++) {
            uint32_t s = collatz_steps(i);
            sum = (sum + s) % MOD;
            if (s > max_s) max_s = s;
        }

        double end = omp_get_wtime();
        seq_times[run] = end - start;
        checksum = sum;
        max_steps_seq = max_s;
        printf("Run %d: %.4f s\n", run + 1, seq_times[run]);
    }

    double T_seq = (seq_times[1] + seq_times[2]) / 2.0; // Warmup (Run 1) отброшен
    printf("Sequential Avg T_seq (Run 2+3): %.4f s | Checksum: %llu | Max Steps: %u\n\n", T_seq, checksum, max_steps_seq);

    // ----------------------------------------------------
    // PHASE 3: Multi-Thread Scaling (OpenMP)
    // ----------------------------------------------------
    printf("--- Phase 3: Scaling Benchmark ---\n");
    int thread_counts[] = {1, 2, 4, 8, 16};
    int num_configs = sizeof(thread_counts) / sizeof(thread_counts[0]);
    int max_t = omp_get_max_threads();

    printf("Threads,Run1,Run2,Run3,Avg_T,S_emp\n");

    double T_2 = 0.0;

    for (int idx = 0; idx < num_configs; idx++) {
        int k = thread_counts[idx];
        if (k > max_t && k != 16) continue;

        double runs[3];
        for (int run = 0; run < 3; run++) {
            double start = omp_get_wtime();
            uint64_t sum = 0;

            #pragma omp parallel for num_threads(k) reduction(+:sum) schedule(static)
            for (uint64_t i = 1; i <= N; i++) {
                sum += collatz_steps(i);
            }

            double end = omp_get_wtime();
            runs[run] = end - start;
        }
        double avg_t = (runs[1] + runs[2]) / 2.0;
        if (k == 2) T_2 = avg_t;
        double s_emp = T_seq / avg_t;

        printf("%d,%.4f,%.4f,%.4f,%.4f,%.4f\n", k, runs[0], runs[1], runs[2], avg_t, s_emp);
    }
    printf("\n");

    // ----------------------------------------------------
    // PHASE 4 - Exp A: False Sharing
    // ----------------------------------------------------
    printf("--- Phase 4: Exp A - False Sharing ---\n");
    int hit_count_naive[MAX_THREADS] = {0};
    double start_fs = omp_get_wtime();
    #pragma omp parallel num_threads(max_t)
    {
        int tid = omp_get_thread_num();
        #pragma omp for
        for (uint64_t i = 1; i <= N; i++) {
            if (collatz_steps(i) > 100) {
                hit_count_naive[tid]++;
            }
        }
    }
    double t_false_sharing = omp_get_wtime() - start_fs;

    int total_hits_mitigated = 0;
    double start_mit = omp_get_wtime();
    #pragma omp parallel for num_threads(max_t) reduction(+:total_hits_mitigated) schedule(static)
    for (uint64_t i = 1; i <= N; i++) {
        if (collatz_steps(i) > 100) {
            total_hits_mitigated++;
        }
    }
    double t_mitigated = omp_get_wtime() - start_mit;

    printf("Naive (False Sharing): %.4f s\n", t_false_sharing);
    printf("Mitigated (Reduction): %.4f s\n", t_mitigated);
    printf("Speedup Penalty Ratio: %.2fx\n\n", t_false_sharing / t_mitigated);

    // ----------------------------------------------------
    // PHASE 4 - Exp B: Loop Scheduling
    // ----------------------------------------------------
    printf("--- Phase 4: Exp B - Scheduling Trade-Offs ---\n");
    
    // Static Default
    double t0 = omp_get_wtime();
    #pragma omp parallel for num_threads(max_t) schedule(static)
    for (uint64_t i = 1; i <= N; i++) collatz_steps(i);
    printf("schedule(static): %.4f s\n", omp_get_wtime() - t0);

    // Static 1000
    t0 = omp_get_wtime();
    #pragma omp parallel for num_threads(max_t) schedule(static, 1000)
    for (uint64_t i = 1; i <= N; i++) collatz_steps(i);
    printf("schedule(static, 1000): %.4f s\n", omp_get_wtime() - t0);

    // Dynamic 100
    t0 = omp_get_wtime();
    #pragma omp parallel for num_threads(max_t) schedule(dynamic, 100)
    for (uint64_t i = 1; i <= N; i++) collatz_steps(i);
    printf("schedule(dynamic, 100): %.4f s\n", omp_get_wtime() - t0);

    // Dynamic 10000
    t0 = omp_get_wtime();
    #pragma omp parallel for num_threads(max_t) schedule(dynamic, 10000)
    for (uint64_t i = 1; i <= N; i++) collatz_steps(i);
    printf("schedule(dynamic, 10000): %.4f s\n", omp_get_wtime() - t0);

    // Guided
    t0 = omp_get_wtime();
    #pragma omp parallel for num_threads(max_t) schedule(guided)
    for (uint64_t i = 1; i <= N; i++) collatz_steps(i);
    printf("schedule(guided): %.4f s\n", omp_get_wtime() - t0);

    return 0;
}